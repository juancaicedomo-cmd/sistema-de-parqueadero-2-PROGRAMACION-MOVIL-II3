package com.example.parqueadero; // Cambia según tu paquete real

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroVehiculoActivity extends AppCompatActivity {

    private EditText etPlaca;
    private Button btnRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_vehiculo);

        // Conectar XML con Java
        etPlaca = findViewById(R.id.etPlaca);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        // Evento del botón
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String placa = etPlaca.getText().toString().trim();

                if (!placa.isEmpty()) {
                    registrarVehiculo(placa); // Llama al método para guardar + notificar
                } else {
                    Toast.makeText(RegistroVehiculoActivity.this, "Ingrese la placa", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para registrar vehículo
    private void registrarVehiculo(String placa) {
        // 1️⃣ Guardar vehículo (simulado)
        System.out.println("Placa guardada: " + placa);

        // 2️⃣ Mostrar notificación en pantalla
        Toast.makeText(this, "Vehículo registrado", Toast.LENGTH_SHORT).show();

        // 3️⃣ Guardar mensaje en Log (consola de Android Studio)
        Log.d("NOTIFICACION", "Vehículo ingresó: " + placa);
    }
}